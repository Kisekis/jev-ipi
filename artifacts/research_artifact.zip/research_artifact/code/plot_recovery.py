"""Plot Luna recovery from the offline summary (same values as Tables 12 and 13).

No experiment execution, new statistical estimates, or manuscript edits.
Values are plotted at the precision in the appendix; small vertical offsets
separate prompt markers without changing their measured x coordinates.
"""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import csv
import argparse

ROOT = Path(__file__).resolve().parents[1]
ARMS = ['Baseline', 'Cautious']
CONFIGS = ['Decisions', 'none', 'low', 'medium', 'high']
COLORS = ['#306882', '#6654A2']
MARKERS = ['o', 's']
ROWS = [4.67, 3.42, 2.37, 1.32, .27]
OFFSETS = [.16, -.16]
INK, MUTED = '#263540', '#52646D'


def draw_panel(ax, data, *, title, ticks, limits, accuracy=False):
    ax.set(xlim=limits, ylim=(-.3, 5.17), xticks=ticks, yticks=[])
    ax.set_title(title, loc='left', color=INK, fontsize=8.4, fontweight='bold', pad=3)
    ax.axhline(4.04, color='#BCCAD0', lw=.55, zorder=1)
    ax.grid(axis='x', color='#DBE4E8', lw=.45, zorder=1)
    ax.set_axisbelow(True)
    for side, spine in ax.spines.items():
        spine.set_visible(side == 'bottom')
    ax.spines['bottom'].set_color('#A4B3BA')
    ax.spines['bottom'].set_linewidth(.55)
    ax.spines['bottom'].set_bounds(ticks[0], ticks[-1])
    ax.tick_params(axis='x', labelsize=7.2, colors=MUTED, length=2.3, width=.45, pad=2)
    ax.tick_params(axis='y', left=False)
    ax.xaxis.set_major_formatter(lambda x, _: f'{x:g}')

    for config, y in zip(CONFIGS, ROWS):
        pair = [data[(arm, config)] for arm in ARMS]
        if pair == [None, None]:
            ax.text(.5, y, 'N/A', ha='center', va='center', color=MUTED,
                    fontsize=7.2, transform=ax.get_yaxis_transform(),
                    bbox={'facecolor':'white', 'edgecolor':'none', 'pad':.6}, zorder=3)
        else:
            ax.plot(pair, [y + d for d in OFFSETS], color='#7C8B94',
                    lw=.8, solid_capstyle='round', zorder=3)

    for arm, color, marker, offset in zip(ARMS, COLORS, MARKERS, OFFSETS):
        xs = [data[(arm, config)] for config in CONFIGS]
        ys = [y + offset for y in ROWS]
        if accuracy:
            # Effort is ordinal. Join observed chat configurations only.
            ax.plot(xs[1:], ys[1:], lw=.9, color=color, alpha=.55, zorder=2)
        ax.plot(xs, ys, linestyle='none', marker=marker, ms=4.5, color=color,
                mec='white', mew=.6, zorder=4)
        if accuracy:
            for i in (0, 2):
                is_baseline = arm == 'Baseline'
                dx = -4 if is_baseline else 4
                dy = -3.2 if i == 2 and is_baseline else (.8 if is_baseline else -.8)
                ax.annotate(f'{xs[i]:.1f}', (xs[i], ys[i]),
                            xytext=(dx, dy),
                            textcoords='offset points', ha='right' if is_baseline else 'left',
                            va='center', color=color, fontsize=7.0, zorder=5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, default=ROOT/'results'/'recovery.csv')
    parser.add_argument('--out', type=Path, default=ROOT/'results'/'figures')
    args = parser.parse_args()
    arm_names = {'no_reminder':'Baseline', 'caution':'Cautious'}
    outcomes, usage = {}, {}
    with args.summary.open(newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            key = (arm_names[r['arm']], 'Decisions' if r['config']=='decisions' else r['config'])
            outcomes[key] = (round(float(r['poisoned_accuracy_pct']), 2),)
            token = r['mean_reasoning_tokens']
            usage[key] = (round(float(token), 2) if token else None,
                          round(float(r['mean_openrouter_seconds']), 3))
    assert len(outcomes) == len(usage) == 10
    plt.rcParams.update({'font.family':['Lato','DejaVu Sans'], 'pdf.fonttype':42})
    fig = plt.figure(figsize=(6.75, 1.70), facecolor='white')
    rects = [(.172, .164, .346, .613), (.552, .164, .196, .613), (.788, .164, .199, .613)]
    a, b, c = [fig.add_axes(r) for r in rects]
    draw_panel(a, {k: v[0] for k,v in outcomes.items()}, title='Poisoned accuracy (%)',
               ticks=[0,25,50,75,100], limits=(-3,112), accuracy=True)
    draw_panel(b, {k: v[0] for k,v in usage.items()}, title='Mean reasoning tokens',
               ticks=[0,10,20,30,40], limits=(-2,43))
    draw_panel(c, {k: v[1] for k,v in usage.items()}, title='Mean latency (s)',
               ticks=[0,.5,1,1.5,2], limits=(-.09,2.12))

    # Single row-label strip shared by the three aligned metrics.
    label = fig.add_axes([.012, .164, .145, .613], sharey=a, frameon=False)
    label.set(xlim=(0,1), xticks=[], yticks=[])
    label.axhline(4.04, color='#BCCAD0', lw=.55)
    label.set_title('Configuration', loc='left', color=INK, fontsize=8.4, fontweight='bold', pad=3)
    for name, y in zip(['Luna Decisions', 'none', 'low', 'medium', 'high'], ROWS):
        label.text(.012 if name == 'Luna Decisions' else .33, y, name, va='center', color=INK,
                   fontsize=8.1, weight='bold' if name == 'low' else 'normal')
    label.text(.012, (ROWS[1] + ROWS[-1]) / 2, 'Chat', va='center', color=MUTED, fontsize=7.1)
    label.plot([.26,.26], [ROWS[-1],ROWS[1]], color='#A5B4BC', lw=.55)

    handles = [Line2D([], [], marker=m, linestyle='none', ms=4.7, color=col, label=arm)
               for arm, col, m in zip(ARMS, COLORS, MARKERS)]
    fig.legend(handles=handles, loc='upper right', bbox_to_anchor=(.994,.979), borderaxespad=0,
               ncol=2, frameon=False, fontsize=7.6, handlelength=.85, handletextpad=.35,
               columnspacing=1.1, labelcolor=INK)
    args.out.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out / 'recovery.pdf', metadata={'Title': 'Luna recovery outcomes and resource use'})
    fig.savefig(args.out / 'recovery.png', dpi=230)
    plt.close(fig)


if __name__ == '__main__':
    main()
