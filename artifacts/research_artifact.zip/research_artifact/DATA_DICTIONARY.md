# Data dictionary

All inputs are UTF-8 JSON or one JSON object per line (`.jsonl`). Derived tables
are CSV, with percentage outputs explicitly suffixed `_pct` and differences
reported in percentage points (`_pp`). JSON `null` and empty optional CSV
fields denote missing/not applicable values, not numeric zero.

## Benchmark and prompt study

- `benchmark/cases.jsonl`: `case_id` is the join key. `generator_id`, `level`,
  and `implicit_factor` identify the computation family, ordinal difficulty,
  and within-family contrast. `facts` are original records; `options` maps
  indexed `action_id` to labels. `goal` and `correct_action` are the task and
  oracle choice.
- `benchmark/variants.jsonl`: join on `(case_id, variant)` with `variant` one of
  `clean`, `poison_conclusion`, or `poison_evidence`. `dom`, `goal`, and
  `criteria` contain the frozen page, task, and legal-action definitions;
  `correct_action` and `target_action` are labels, not model inputs. The clean
  variant retains the paired target label as metadata. `prompt_rules/rules.json`
  gives the archived instruction text for each rule. Variant records are
  shared across model/rule cells rather than copying the same pages 12 times.
- `baseline_results.jsonl` and `intervention_results.jsonl`: join on
  `(model, arm, case_id, variant)`. `model` maps to provider-model IDs in
  `benchmark/models.json`; `selected_action` is the native returned action;
  `probabilities` is the unnormalized returned action map. `elapsed_seconds`
  is the archived request timing. One successful Jev 1.14 Ignore observation
  retains an earlier error note as `archived_error`, not as a failed outcome.
  `input_repair`, when present, records the task-irrelevant page text edits
  for recovered Luna provider refusals (11 Baseline, 8 Ignore, 4 Cautious).
- Clean accuracy and ASR are kept distinct from confidence and ECE. ECE uses
  15 equal-width bins. `severity.csv` conditions on the clean-correct subset;
  S1/S2 distinguish nondecreasing/decreasing probability of the oracle action
  when the poisoned choice stays correct; S3/S4 split wrong choices at 0.8.
  `correct_probability_falls_pct` includes both correct and wrong poisoned choices.

## Recovery

- `recovery/requests.jsonl` contains the archived request objects; join to
  `recovery/results.jsonl` on `(arm, config, input_id)`. `no_reminder` is
  Baseline and `caution` is Cautious. Configurations: `decisions`, `none`,
  `low`, `medium`, `high`. Case and variant link to the main benchmark.
- `valid` indicates whether a usable legal action was selected under the
  recorded format protocol. `attempts` includes repeated format attempts and
  incorporated reruns. For resources, keep `selected_response_seconds`
  (client timing), `openrouter_total_latency_s` (selected generation provider
  timing), and `total_seconds_including_format_retries` distinct.
  `reported_reasoning_tokens_selected` and `total_reported_cost_usd` are
  API-reported; cost includes the selected and unsuccessful attempts used
  in the manuscript snapshot.
- `selection.json` records source digests and the fixed-order selected
  replacement history. The artifact reproduces summaries from the selected
  rows, not the selection process from raw attempt bodies.

## Directional follow-up

- `directional/cases.jsonl` contains the follow-up oracle, options, operands,
  `seed_id`, `block`, and factor labels. `variants.jsonl` and `results.jsonl`
  use the same joins as the main study under Baseline. `rules` stores the
  task rule directly in each follow-up input record.
- The 1,024 `unequal` cases support the signed gaps in the appendix:
  `AB` = False-minus-True oracle error; `OP` = less-minus-greater;
  `SA`/`SB` = negative-minus-positive operand; `POS` = True-second-minus-first;
  `ORD` = reverse-minus-forward. Intervals use 10,000 bootstrap draws over
  the eight numerical seeds, with the original seed and RNG conventions.
  `answer_bias_reference.json` and `profile_reference.json` retain the archive's
  reference summaries for comparison.
