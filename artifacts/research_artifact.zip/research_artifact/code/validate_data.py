"""Validate the joins, labels, and row counts of the bundled frozen data."""
from collections import Counter
from itertools import product
from analyze import ARMS, MODELS, ROOT, VARIANTS, read
import json


def index(rows, *fields):
    d = {tuple(r[f] for f in fields):r for r in rows}
    assert len(d) == len(rows), fields
    return d


def decisions(cases, variants, outputs, arms):
    index(cases, 'case_id')
    inputs=index(variants,'case_id','variant')
    assert inputs.keys()==set(product([c['case_id'] for c in cases],VARIANTS))
    actions={c['case_id']:{o['action_id'] for o in c['options']} for c in cases}
    correct={c['case_id']:c['correct_action'] for c in cases}
    for (case_id,_),r in inputs.items():
        assert set(r['criteria'])==actions[case_id]
        assert r['correct_action']==correct[case_id] and r['target_action'] in actions[case_id]
        assert r['target_action']!=r['correct_action']
    replies=index(outputs,'model','arm','case_id','variant')
    assert replies.keys()=={(m,a,c,v) for m,a in product(MODELS,arms) for c,v in inputs}
    for (_,_,c,v),r in replies.items():
        assert r['valid'] and r['http_status']==200
        assert set(r['probabilities'])==actions[c] and r['selected_action'] in actions[c]
        assert all(0<=p<=1 for p in r['probabilities'].values())
        expected=inputs[c,v]
        assert all(r[k]==expected[k] for k in ('correct_action','target_action'))
        for edit in r.get('input_repair',[]):
            assert edit['field']=='state.dom' and edit['original'] in expected['dom']
    return len(replies)


def main():
    cases=read('benchmark/cases.jsonl')
    assert len(cases)==1440
    cells=Counter((r['generator_id'],r['level']) for r in cases)
    assert len(cells)==48 and set(cells.values())=={30}
    rule_data=json.loads((ROOT/'data/prompt_rules/rules.json').read_text())
    assert set(rule_data)==set(ARMS)
    runs=read('benchmark/baseline_results.jsonl')+read('prompt_rules/intervention_results.jsonl')
    assert Counter(r['arm'] for r in runs if r.get('input_repair'))=={'baseline':11,'ignore':8,'cautious':4}
    n=decisions(cases,read('benchmark/variants.jsonl'),runs,ARMS)
    print(f'Benchmark: {len(cases):,} cases, {n:,} model observations over all rules.')
    dc=read('directional/cases.jsonl')
    assert Counter(c['block'] for c in dc)=={'unequal':1024,'equal':512}
    nd=decisions(dc,read('directional/variants.jsonl'),read('directional/results.jsonl'),('baseline',))
    print(f'Directional follow-up: {len(dc):,} cases, {nd:,} model observations.')
    recovery=read('recovery/results.jsonl')
    rr=index(recovery,'arm','config','input_id')
    rq=index(read('recovery/requests.jsonl'),'arm','config','input_id')
    assert rr.keys()==rq.keys() and len(rr)==1440
    assert len({r['case_id'] for r in recovery})==48
    assert sum(not r['valid'] for r in recovery)==1
    assert {(r['case_id'],r['variant']) for r in recovery}<={(r['case_id'],r['variant']) for r in read('benchmark/variants.jsonl')}
    assert set(Counter((r['arm'],r['config'],r['variant']) for r in recovery).values())=={48}
    print('Luna recovery: 48 paired cases, 1,440 observations, one retained format failure.')


if __name__=='__main__':
    main()
