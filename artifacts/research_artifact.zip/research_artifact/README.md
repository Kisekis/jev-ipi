# Too Fast to Doubt? — code and data artifact

This artifact supports offline reproduction of the numerical results in
*Too Fast to Doubt? Skipping Reasoning Leaves Jev-like Models Vulnerable*.
It accompanies the November 20, 2026 manuscript source bundle. It is separate
from the LaTeX submission package and does not include a model runner.

## Start here

Use Python 3.11 or later. The core analysis uses only the standard library;
no credentials, network, or experiment workspace are needed.

```sh
python3 -B code/validate_data.py
python3 -B code/analyze.py
```

For the directional bootstrap intervals and the Figure 7 redraw, use
NumPy and Matplotlib (tested versions in `requirements-optional.txt`):

```sh
python3 -m pip install -r requirements-optional.txt
python3 -B code/analyze.py --bootstrap
python3 -B code/plot_recovery.py
```

`analyze.py --out PATH` writes CSVs to a separate directory; it does not modify
the inputs or the reference tables. The packaged `results/` contains the
outputs including bootstrap intervals. The verification step checks numerical
cells in the paper's 10 result tables and, with `--bootstrap`, the archived
interval endpoints (820 checks total). The plot uses Lato where installed and
falls back to DejaVu Sans; typography can vary between environments.

## Contents

| Directory | Data |
|---|---|
| `data/benchmark/` | 1,440 frozen synthetic cases (six families × eight levels × 30 cases), 4,320 page variants, and 17,280 Baseline observations for four direct decision configurations. |
| `data/prompt_rules/` | Original three rule texts and 34,560 Ignore/Cautious observations. Use the Baseline observations from `benchmark/` for the full 51,840-observation comparison. |
| `data/recovery/` | The 48 matched tasks, 1,440 request records and manuscript-selected observations across two prompts and five Luna configurations. Includes selection provenance and one unresolved format failure. The 48 cases are a subset of the main benchmark, not an additional benchmark. |
| `data/directional/` | 1,536 additional comparison cases, 4,608 page variants, and 18,432 Baseline observations across four configurations. The manuscript analyzes the 1,024 unequal cases; 512 equality cases remain available. |
| `paper_tables/` | Exact result-table snapshots used by the verifier, copied from the arXiv source package. |
| `results/` | CSVs for capability, calibration, severity, confidence thresholds, prompt rules and transitions, recovery, and directional gaps/intervals. `figures/` contains a Figure 7 redraw. |

The case and request payloads are fixed synthetic records. They are not a
live-site crawler or an automated injection tool. Raw service traces,
credentials, internal notes, API runner scripts, unrelated historical runs,
and provider generation IDs are outside the artifact. The separate source
package has no dependency on this artifact.

## Read these distinctions before using the numbers

- **RQ1/RQ2 use Baseline.** The frozen cases originated in a different run;
  its Jev 1.13 Cautious measurements must not replace the current manuscript's
  Baseline measurements. The provenance manifest identifies the specific
  source file for each model × rule cell.
- **Tie rules differ slightly across pipelines.** Main-study RQ1/RQ2 and
  directional results use exact ties. RQ3 appendix calibration and severity
  follow the archived pipeline's `1e-12` tie tolerance. In either pipeline,
  select the native returned action if it is tied, otherwise the lowest
  numeric action ID. RQ3 clean accuracy, ASR, and transition counts use
  *native* choices directly. Probabilities are not renormalized.
- **Do not conflate the pooled rates.** Two-shot ASR counts a base case hit by
  either payload. Pooled prompt/recovery ASR counts the two poisoned page
  variants as separate observations. Neither is one minus poisoned accuracy.
- **Recovery resources.** Mean and P95 latency are OpenRouter Total Latency
  of the selected generation, in seconds, not cumulative wall-clock time.
  Token counts are API-reported; missing native token counts are not zero.
  One unresolved format failure stays in the denominator, neither correct nor
  targeted. Do not interpret native–chat or cross-batch differences as an
  isolated causal effect of reasoning tokens.

See [DATA_DICTIONARY.md](DATA_DICTIONARY.md) for keys and units. The
source-of-record file IDs and SHA-256 values are in `provenance.json`; bundle
checksums are in `SHA256SUMS`. No release license is assigned by this bundle.
