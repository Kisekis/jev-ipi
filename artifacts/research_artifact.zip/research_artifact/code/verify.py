"""Check recomputed values against the tables bundled with the manuscript."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
MODELS = dict(zip(('Jev 1.13','Jev 1.14','Luna Decisions','Microsoft Decision-1'),
                  ('jev113','jev114','luna-decisions','microsoft-decision')))
FAMILIES = dict(zip(('Comparison','Sum','Difference','Expression','Product','Percentage','Overall'),
                    ('num_compare','sum_choice','difference','expression_eval','product','percent','Overall')))
V = ('clean','poison_conclusion','poison_evidence')


def rows(stem, n):
    for line in (ROOT/'paper_tables'/f'{stem}.tex').read_text().splitlines():
        if not line.endswith(r' \\'):
            continue
        cells = [re.sub(r'\\TableTint\{[^}]*\}\{[^}]*\}|\\bfseries', '', c).strip() for c in line[:-3].split('&')]
        if len(cells)==n:
            yield cells


def model(text):
    return MODELS[re.search(r'\\modelname\{([^}]+)\}',text)[1]]


def indexed(rows, *keys):
    out={tuple(row[x] for x in keys):row for row in rows}
    assert len(out)==len(rows)
    return out


def verify(out, with_bootstrap):
    n=0
    def compare(value, expected, where, digits=2):
        nonlocal n
        if expected in ('{---}', '---'):
            assert value is None, (where,value,expected)
        else:
            assert value is not None and abs(value-float(expected)) <= .5*10**(-digits)+1e-8, (where,value,expected)
        n+=1
    def cells(r, keys, expected, where, digits=2):
        assert len(keys)==len(expected),where
        for key,v in zip(keys,expected): compare(r[key],v,f'{where}/{key}',digits)
    cap=indexed(out['capability'],'model','scope','group')
    cal=indexed(out['calibration'],'model','scope','group','variant')
    sev=indexed(out['severity'],'model','scope','group','variant')
    checked=0
    for line in rows('capability_all_models',17):
        family=FAMILIES.get(line[0].replace(r'\textbf{Overall}','Overall'))
        if not family: continue
        checked+=1
        for i,m in enumerate(MODELS.values()):
            r=cap[m,'overall' if family=='Overall' else 'family',family]
            cells(r,['clean_accuracy_pct','conclusion_asr_pct','evidence_asr_pct','two_shot_asr_pct'],line[1+4*i:5+4*i],(m,family),1)
    assert checked==7
    for line in rows('confidence_all_models',10):
        if not line[0].startswith(r'\modelname'):continue
        m=model(line[0])
        for i,v in enumerate(V):
            cells(cal[m,'overall','Overall',v],['accuracy_pct','confidence_pct','ece_pct'],line[1+3*i:4+3*i],(m,v))
    for line in rows('rq2_paired_severity',9):
        if line[1] not in ('Conclusion','Evidence'):continue
        if line[0]:m=model(line[0])
        r=sev[m,'overall','Overall','poison_'+line[1].lower()]
        compare(r['n0'],line[2],(m,line[1],'n0'),0)
        cells(r,[f's{i}_pct' for i in range(1,5)]+['correct_probability_falls_pct','s4_among_wrong_pct'],line[3:],(m,line[1]))
    levels=[line for line in rows('calibration_levels_all_models',6) if line[0].isdigit()]
    assert len(levels)==32
    for i,line in enumerate(levels):
        m=list(MODELS.values())[i//8]; level=line[0]
        for j,v in enumerate(V):compare(cal[m,'level',level,v]['ece_pct'],line[j+1],(m,v,level,'ece'))
        for j,v in enumerate(V[1:]):compare(sev[m,'level',level,v]['s4_pct'],line[4+j],(m,v,level,'s4'))
    rules=indexed(out['prompt_rules'],'model','arm')
    for line in rows('prompt_overview',9):
        if line[1] not in ('Baseline','Ignore','Cautious'):continue
        if line[0]: m=model(line[0])
        arm=line[1].lower()
        cells(rules[m,arm],['clean_accuracy_pct','conclusion_asr_pct','evidence_asr_pct','pooled_asr_pct','e0_pct','ef_c_pct','ef_e_pct'],line[2:],(m,arm))
    transitions=indexed(out['prompt_transitions'],'model','arm')
    for line in rows('prompt_transitions',6):
        if line[1] not in ('Ignore','Cautious'):continue
        if line[0]:m=model(line[0])
        arm=line[1].lower()
        cells(transitions[m,arm],['conclusion_removed','conclusion_new','evidence_removed','evidence_new'],line[2:],(m,arm),0)
    cautious=indexed(out['cautious_severity'],'model','variant')
    for line in rows('cross_severity',7):
        if not line[0].startswith(r'\modelname'):continue
        m=model(line[0]); v='poison_'+line[1].lower()
        compare(cautious[m,v]['n0'],line[2],(m,v,'n0'),0)
        cells(cautious[m,v],[f's{i}_pct' for i in range(1,5)],line[3:],(m,v))
    rec=indexed(out['recovery'],'arm','config')
    for stem,size in [('reasoning_recovery',7),('recovery_usage',5)]:
        for line in rows(stem,size):
            if line[1] not in ('Decisions','none','low','medium','high'):continue
            if line[0]:arm={'Baseline':'no_reminder','Cautious':'caution'}[line[0]]
            config=line[1].lower(); r=rec[arm,config]
            if stem=='reasoning_recovery':
                cells(r,['clean_accuracy_pct','poisoned_accuracy_pct','conclusion_asr_pct','evidence_asr_pct','pooled_asr_pct'],line[2:],(arm,config))
            else:
                compare(r['mean_reasoning_tokens'],line[2],(arm,config,'reasoning'))
                cells(r,['mean_openrouter_seconds','p95_openrouter_seconds'],line[3:],(arm,config),3)
    assert sum(r['format_failures'] for r in rec.values())==1
    for r in out['comparison_truth']:
        compare(r['conclusion_asr_pct'],90 if r['truth']=='True' else 20,'original comparison subgroup',1)
    signed=[line for line in rows('comparison_directional_bias',8) if line[0].startswith(r'\modelname')]
    assert len(signed)==12
    d=indexed(out['directional'],'model','variant')
    for i,line in enumerate(signed):
        m=model(line[0]);v=V[i//4]
        cells(d[m,v],['rate_pct','AB','OP','SA','SB','POS','ORD'],line[1:],(m,v))
    if with_bootstrap:
        ints=indexed(out['directional_intervals'],'model','variant','metric')
        rs=json.loads((ROOT/'data/directional/profile_reference.json').read_text())
        assert len(rs)==len(ints)==72
        for r in rs:
            key=r['slug'],r['condition'],r['metric']
            compare(ints[key]['lower_pp'],r['ci_low'],key,8)
            compare(ints[key]['upper_pp'],r['ci_high'],key,8)
    return n
